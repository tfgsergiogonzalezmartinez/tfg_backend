export interface UserLoginDto {
  Email : string;
  Password : string;
}
