export interface Direccion {
  DireccionEnvio : string;
  DireccionFacturacion : string;
  Ciudad : string;
  Cp : string;
  Provincia : string;
  Pais : string;
}
