export interface ImagenDto {
    Imagen : string;
}
