import { TruncarPipe } from './truncar.pipe';

describe('TruncarPipe', () => {
  it('create an instance', () => {
    const pipe = new TruncarPipe();
    expect(pipe).toBeTruthy();
  });
});
