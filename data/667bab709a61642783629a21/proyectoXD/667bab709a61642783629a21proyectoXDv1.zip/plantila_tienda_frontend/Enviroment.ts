export const Enviroment = {
  BACKEND_URL : 'http://aa:5000/',
  BACKEND_API_URL : 'http://aa:5000/api/',

  PAGE_ICON : 'assets/img/Logo.png',
  PAGE_TITULO : 'Tienda',
  PAGE_BACKGROUND_COLOR : 'white',
  PAGE_MONEDA : '$',
}
