export interface UserCambiarPassword {
  Email: string ;
  PasswordAntigua: string;
  PasswordNueva1: string;
  PasswordNueva2: string;
}
