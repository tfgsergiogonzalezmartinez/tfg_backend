import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-LoginLayout',
  templateUrl: './LoginLayout.component.html',
  styleUrls: ['./LoginLayout.component.css']
})
export class LoginLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
