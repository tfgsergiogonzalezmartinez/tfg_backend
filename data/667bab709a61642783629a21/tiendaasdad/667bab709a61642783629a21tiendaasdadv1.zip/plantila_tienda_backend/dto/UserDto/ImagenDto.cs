using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tfg_backend.dto.UserDto
{
    public class ImagenDto
    {
        public string Imagen { get; set; }
    }
}