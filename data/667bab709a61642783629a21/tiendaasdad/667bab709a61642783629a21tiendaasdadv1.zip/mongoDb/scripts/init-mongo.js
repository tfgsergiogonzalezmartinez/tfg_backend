const { execSync } = require('child_process');
const fs = require('fs');

// Lee los archivos JSON
const productos = JSON.parse(fs.readFileSync('/docker-entrypoint-initdb.d/dbModelos/bbdd_productos.json', 'utf8'));
const categorias = JSON.parse(fs.readFileSync('/docker-entrypoint-initdb.d/dbModelos/bbdd_categorias.json', 'utf8'));

// Construye la cadena de conexión
const username = process.env.MONGO_INITDB_ROOT_USERNAME;
const password = process.env.MONGO_INITDB_ROOT_PASSWORD;
const dbName = process.env.DB_NAME;
const authDb = process.env.MONGO_AUTH_DB;
const port = process.env.DB_PORT;
const connectionString = `mongodb://${username}:${password}@localhost:${port}/${dbName}?authSource=${authDb}`;

const insertData = (collection, data) => {
  const command = `mongosh "${connectionString}" --eval 'db.${collection}.insert(${JSON.stringify(data)})'`;
  execSync(command, { stdio: 'inherit' });
};

try {
  insertData('Productos', productos);
  insertData('Categorias', categorias);
  console.log('Datos insertados exitosamente');
} catch (error) {
  console.error('Error al insertar datos:', error);
}
