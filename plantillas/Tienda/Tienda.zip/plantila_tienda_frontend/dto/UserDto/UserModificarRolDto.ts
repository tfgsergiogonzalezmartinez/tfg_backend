export interface UserModificarRolDto {
  Email: string;
  Rol: string;
}
