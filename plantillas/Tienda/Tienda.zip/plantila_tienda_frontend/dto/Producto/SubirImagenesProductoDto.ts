export class SubirImagenesProductoDto {
  IdProducto!: string;
  Fotos!: string[];
  FotoPrincipal!: string;
}
