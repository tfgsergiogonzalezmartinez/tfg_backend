export interface VentaProducto {
  Producto: string;
  Talla: string;
  Color: string;
  Precio: number;
}
