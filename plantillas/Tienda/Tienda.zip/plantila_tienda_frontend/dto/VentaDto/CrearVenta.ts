import { VentaProducto } from "./VentaProducto";

export class CrearVenta {
  Usuario: string = "";
  Productos: VentaProducto[] = [];
  Total: number = 0;
}
