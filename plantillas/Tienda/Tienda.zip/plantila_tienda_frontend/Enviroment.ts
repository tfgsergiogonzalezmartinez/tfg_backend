export const Enviroment = {
  BACKEND_URL : 'http://localhost:5000/',
  BACKEND_API_URL : 'http://localhost:5000/api/',

  PAGE_ICON : 'assets/img/Logo.png',
  Titulo : 'Tienda',
  Moneda : '€',
  Logo_Extension : 'png',
}
