export const Enviroment = {
  BACKEND_URL : 'http://localhost:5157/',
  BACKEND_API_URL : 'http://localhost:5157/api/',

  PAGE_ICON : 'assets/img/Logo.png',
  Titulo : 'Tienda',
  Moneda : '$',
  Logo_Extension : 'webp',
}
