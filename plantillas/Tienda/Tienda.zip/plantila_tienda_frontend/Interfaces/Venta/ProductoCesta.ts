export class ProductoCesta {
    public Producto!: string;
    public Talla!: string;
    public Color!: string;
    public Precio!: number;
    public FotoPrincipal!: string;
}
